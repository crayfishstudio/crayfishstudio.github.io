<?php
session_start();
require_once("config.php");
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: adminlog.php");
    exit;
}
if(isset($_GET["logout"])) {


// Unset all of the session variables
    $_SESSION = array();

// Destroy the session.
    session_destroy();

// Redirect to login page
    header("location: adminlog.php");
    exit;
}
$id = $_GET['id'];
$sql = "DELETE FROM posts WHERE id = $id";
$db->query($sql);
header("Location: admin.php");
exit;
?>
